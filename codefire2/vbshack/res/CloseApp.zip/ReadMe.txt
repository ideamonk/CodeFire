--------------------------------------------------------------------------------

  CloseApp - Version 1.03                                           README.TXT
  Copyright � 2003-2006, No�l DANJOU                                April 2006
  All rights reserved.

--------------------------------------------------------------------------------


About CloseApp
------------------

  CloseApp is a small command-line tool that allows you to close all the
  processes whose executable filename matches the one passed as a parameter.
  Alternatively, you can pass a DLL filename as a parameter to close all 
  processes using that library.

  The included and redistributable psapi.dll file is only needed if you use 
  CloseApp in a Command-Prompt of Windows NT 4.0.

  Run closeapp.exe from a Command Prompt to learn more about its syntax.

  Syntax:   CloseApp notepad.exe <Enter>



History
-------


  * April 12, 2006 - Version 1.03 (build 9.3)

    - fully rewrote the process enumeration code
    - the filename may either be an executable or a library (DLL)
    - services are now identified as such and gracefully stopped


  * May 18, 2005 - Version 1.02 (build 6.3)

    - enhanced the code that gracefully closes an application


  * November 25, 2004 - Version 1.01 (build 5.2)

    - added /timeout optional parameter


  * September 3, 2004 - Version 1.0 (build 4.5)

    - fixed the "access denied" error when forcing a process to close


  * April 24, 2003 - Version 1.0 (build 3.4)

    - fixed a "handle is invalid" error even though the process was closed.
    - CloseApp did not work on Windows 9x/Me systems, this is also fixed.


  * April 10, 2003 - Version 1.0 (build 1.3)

    - Initial build.



Latest versions 
---------------

  The latest version of CloseApp is always available from my website:
  
    http://noeld.com/programs.asp?cat=misc#CloseApp



Contact details
---------------


  E-mail:

    webmaster@noeld.com


  WWW:

    http://noeld.com
